from release import version
__version__ = version

from zhpy import *
