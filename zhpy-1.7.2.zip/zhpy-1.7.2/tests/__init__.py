"""
test with command::

    nosetests --with-doctest

"""


#always run annotator before access worddict
#from zhpy import annotator

#annotator()
