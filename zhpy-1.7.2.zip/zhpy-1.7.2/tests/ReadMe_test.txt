install nose testtool to test::

    $ easy_install nose

to test zhpy, enter the top zhpy directory and execute the command::

    $ nosetests --with-doctest