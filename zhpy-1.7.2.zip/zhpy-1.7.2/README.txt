zhpy
====

zhpy is the python on Chinese, which is good for Taiwan and China beginners
to learn python in our native language.

Install: http://code.google.com/p/zhpy/wiki/DownloadInstall

Open the command line, enter the current source directory and type following
command:

$ python setup.py install


Basic Usage: http://code.google.com/p/zhpy/wiki/BasicUsage


To play zhpy you even don't need to install it.

All you need to do is follow the 3 steps guide:

  1. Download the source pack
  2. Extract the pack with zip tool
  3. Run::

      $ python interpreter.py

Then you got the usable zhpy interpreter!
