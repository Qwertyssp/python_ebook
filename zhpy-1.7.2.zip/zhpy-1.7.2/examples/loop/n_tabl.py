# -*- coding: utf-8 -*-
def p_7b97_8868_v(p_8868_683c_5927_5c0f_v):
    for p_4e58_6578_v in range(1, p_8868_683c_5927_5c0f_v+1):
        for p_88ab_4e58_6578_v in range(1, p_8868_683c_5927_5c0f_v+1):
            print "%d*%d=%d"%(p_4e58_6578_v,p_88ab_4e58_6578_v,p_4e58_6578_v*p_88ab_4e58_6578_v)

p_7b97_8868_v(9)