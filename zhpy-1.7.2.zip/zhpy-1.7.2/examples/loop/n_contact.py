#coding=utf-8
# by jiahua huang

p_59d3_540d_8868_v=('张三','李斯','王海','荷花')
def p_6253_5370_59d3_540d_8868_v():
    count=1
    for p_59d3_540d_v in p_59d3_540d_8868_v:
    	print count, p_59d3_540d_v
    	count+=1

if __name__=="__main__":
	p_6253_5370_59d3_540d_8868_v()