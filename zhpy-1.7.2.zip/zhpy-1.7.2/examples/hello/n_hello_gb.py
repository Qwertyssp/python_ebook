argv=1
print argv

for i in range(10):
    print i