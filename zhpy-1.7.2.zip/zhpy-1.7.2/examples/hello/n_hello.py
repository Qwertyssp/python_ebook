# -*- coding: utf-8 -*-
# this is a sample Python program
def p_7bc4_4f8b_v_1(p_8a0a_606f_v, p_6b21_6578_v):
   for p_6578_v in range(p_6b21_6578_v):
       print "哈囉, %s!" % p_8a0a_606f_v

p_7bc4_4f8b_v_1("世界", 100)