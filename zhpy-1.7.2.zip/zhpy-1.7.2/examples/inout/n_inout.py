# -*- coding: utf-8 -*-
p_8cc7_6599_v = raw_input("輸入姓名: ")
print "歡迎,", p_8cc7_6599_v